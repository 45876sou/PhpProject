
<?php
$cop="<img src='cap.php'>";
echo "$cop";
?>